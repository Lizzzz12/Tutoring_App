import React from "react";

const Tutors = () => {
  return <h2>Find a Tutor</h2>;
};

export default Tutors;
